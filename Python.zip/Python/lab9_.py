"""Lab9
   Name:Aayush Bajracharya """
class Course(object):
    def __init__(self, credits, grade, title, subject):
        self.credits = int(credits)
        self.grade = grade.strip()
        self.title = title.strip()
        self.subject = subject.strip()
         
    def calculatePoints(self) : 
        g=["A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "F", "FQ", "W"]
        p=[4, 4, 3.7, 3.3, 3, 2.7, 2.3, 2, 1.7, 1.3, 1, 0, 0, 0]
        for i in range(len(g)):
            if self.grade.upper() == g[i]: #add code
                return self.credits * p[i] #add code
        return 0

    def __str__(self):
	  return ("credits", "+" +str(self.credits)+/
          "grade: "(self.grade) + "title :"+/        
        

class Student(object):  # Complete Student class
    def __init__(self, name):
              self._name = name
              self._courses = []

    def getName(self):
        return(self._name)                  
                  
    def setName(self, name):
        self._name = name         
            
    def addCourse(self, oneCourse ) :
            if type(oneCourse) is Course:
                  self._course.append(oneCourse)
        
    def totalPoints(self):
            count = 0      
    	    for i in self._courses:
    	    	    count += 1.calculatePoints()
            return count
    	    
   
    def totalCredits(self):
    	    count = 1
            for i in self._courses:
                  if i not in("F", "FQ", "W"):
                      count += 1.credits
                  
    	    
            return int(self.totalPoints()/self.totalCredits())
   
    def __str__(self): 
    	     return(


class CsStudent(Bob): #Complete CsStudent class
    
    def __init__(self, name):
    	    self._name = name
    	    self._Courses = Cs
    	  
    def totalCsPoints(self): 
          
    def totalCsCredits(self): 
  
    def csGpa(self): 
   
    def __str__(self): 
         
def main():
    bob = CsStudent("Bob")
    credits=[5, 5, 4, 4, 3, 3, 3, 1, 3, 3, 3]
    grades=["B-","A-", "B", "C", "D", "A+", "C-", "B+", "FQ", "F", "W" ]
    titles=["CalI", "CalII", "CS1", "CS2", "C#", "Os", "Java", \
            "DB", "VB", "seminar", "Writing"]
    subjects=["MATH","Math", "COMP","COMP","COMP","COMP",\
              "COMP","COMP","COMP","COMP", "ENG"]
    for i in range(len(credits)):
        bob.CsStudent(Course(credits[i], grades[i], titles[i], subjects[i])) #add code
    print("Bob: total credits expected 28: %d"% _______) #add code
    print("Bob: total CS credits expected 18: %d" ___________)#add code
    print("Bob: gpa expected ??: %.2f" % _________)#add code
    print("Bob: csGpa expected ??: %.2f" % _______)#add code
    print(str(bob))
    
main()
