/******************************************************************************
 Aayush Bajracharya
 Unix Lab Assignment 3
 This program Encrypts And/Or Decrypts a file transposing the characters
 into a multidimensional array in the key n.
 Oct 17th, 2017
 
 ******************************************************************************/

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>

using namespace std;

void Read(ifstream &, char ** A, int key);
// Post : n^2 number of character from sourcefile read to the multidimensional array of key n.
// Pre  : A should be multidimensional array of key n.

void Transpose(char** A, int key);
//Post : Transpose n^2 number of characters from the array by exchanging the rows and columns.
// Pre  : A should be multidimentsional array of key n.

void Write(ofstream& myOut, char** A, int key);
// Post : write n^2 number of character from the transposed multidimensional array to a text file with .cc
// Pre : A should be multidimensional array of key n.

int main()
{
    
    char source[70];
    char output[70];
    int select;
    int key;
    
    cout << "Enter 1 for Encryption or 2 for Decryption" << endl;
    cout << "Enter your Selection:";
    cin >> select;
    if (select == 1)
    {
        cout << "Enter the name of the file:";
        cin >> source;
        cout << endl << endl;
        cout << "Enter the name of the output file:"; //prompts the user for the name of the
                                                      //output file that is going to be encrypted.
        cin >> output;
        cout << endl << endl;
        
    }
    if (select == 2)
    {
        cout << "Enter the name of the Encrypted File: ";
        cin >> source;
        cout << endl;
        cout << "Enter the name of the output file:" ;//prompts the user for the name of the
                                                    //output file that is going to be decrypted.
        cin >> output;
    }
    else
    {
        cout << "INVALID ENTRY. Please enter 1 for Encryption or 2 for Decryption :";
        cin >> select;
    }
    //I was confused on the code to use to let the user return to the part where they start all over so I just did the same process twice.
    if (select == 1)
    {
        cout << "Enter the name of the file:";
        cin >> source;
        cout << endl << endl;
        cout << "Enter the name of the output file:"; //prompts the user for the name of the
        //output file that is going to be encrypted.
        cin >> output;
        cout << endl << endl;
        
    }
    if (select == 2)
    {
        cout << "Enter the name of the Encrypted File: ";
        cin >> source;
        cout << endl;
        cout << "Enter the name of the output file:" ;//prompts the user for the name of the
        //output file that is going to be decrypted.
        cin >> output;
    }
    
    
    
    ifstream myIn;
    
    
    myIn.open(source);  //try to open the source file
    
    //check to see if the file opened or not
    if (myIn.fail())
    {
        cout <<"Error opening file!!!"<<endl;
        exit(EXIT_FAILURE);
    }
    cout << "Enter the Encryption key for the input file:";
    cin >> key;
    
    ofstream myOut;  // Attempt to open the file
    myOut.open(output);
    if (myOut.fail())
    {
        cout << "Error opening file." <<endl;
        exit (EXIT_FAILURE);
    }
    char ** A3; //multidimensional pointer A3
    A3 = new char* [key];
    for (int i = 0; i < key; i++)
    {
        A3[i] = new char[key];
    }
    while(!myIn.eof()) // Executes  until the end of file.
    {
        Read(myIn, A3 , key);
        Transpose ( A3, key );
        Write(myOut, A3, key);
    }
    
    myIn.close(); //closing the input file
    myOut.close(); //closing the output file.
    return 0;
}

void Read(ifstream& myIn,char ** A, int key)
{
    char ch;
    for(int i= 0; i < key; i++)
    {
        for(int j = 0; j < key; j++)
        {
            myIn.get(ch); // gets a character from the input file.
            A[i][j] = ch; // loads a charatcter in the multidimensional array of key n.
            
        }
    }
    
}

void Transpose(char ** A, int key)
{
    char ** B;  // new multidomensional array pointer
    B = new char* [key];
    // This creates new empty multi dimensional array B of key
    for(int i = 0; i < key; i++)
    {
        B[i] = new char [key];
    }
    for(int i = 0; i < key; i++)
    {
        for(int j = 0; j < key; j++)
        {
            B[i][j]=A[i][j]; // copying elements from A to B in same order.
            A[i][j]='a';     // filling A with all 'a' on it.
        }
    }
    for(int i = 0; i < key; i++)
    {
        for(int j = 0; j < key; j++)
        {
            A[j][i]=B[i][j]; // copying all B elements to A in transpose order.
        }
    }
    
}

void Write(ofstream& myOut ,char**A , int key)
{
    for(int i = 0; i < key; i++)  //loop to access each and every elements.
    {                                        // from transposed matrix.
        for(int j = 0; j < key; j++)
        {
            myOut<<A[i][j];   //writes each transposed elements in output file.
        }
    }
}


