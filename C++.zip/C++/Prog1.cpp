/*********************************************************************************
Aayush Bajracharya
UNIX Programming 
 
This program prompts the user to enter two random points making a rectangle and, 
one random co-ordinate and checks if that point is inside the rectangle or not.
The program ends when the user enters (0,0) for both points.
**********************************************************************************/



#include <iostream>
#include <cstdlib>

using namespace std;

int main()
{
    int x;         //The x co-ordinate for the upper left point
    int y;         //The y co-ordinate for the upper left point
    int x1;        //The x co-ordinate for the lower right point
    int y1;        //The y co-ordinate for the lower right point
    int a;         /*The x co-ordinate for the point that is to be
                    checked whether it is inside the rectangle or not*/
    int b;         /*The y co-ordinate for the point that is to be
                     checked whether it is inside the rectangle or not*/
    
    do{
        cout<<"Enter x coordinate for upper left corner of the rectangle:";
        cin>>x;
        cout<<"Enter y coordinate for upper left corner of the rectangel:";
        cin>>y;
        cout<<"Enter x coordinate for lower right corner of the rectangle:";
        cin>>x1;
        cout<<"Enter y coordinate for lower right corner of the rectangel:";
        cin>>y1;
        cout<<"Enter the x coordinate for a point(test point):";
        cin>>a;
        cout<<"Enter the y coordinate for a point(test point):";
        cin>>b;
        
        cout<<"The two points for the rectangle are :("<<x<<" , "<<y<<") & ("<<x1<<", "<<y1<<")"<<endl;
        cout<<"The point that is to be checked if it lies inside the rectangle : ("<<a<<" ,"<<b<<")"<<endl;
        if (x==0 && y==0 && x1 ==0 && y1 ==0)
        {            cout<<"The program is now shutting down!!!"<<endl;
            exit(1);
        }
        else if(a>x && a<x1)
        {
            if(b>y && b<y1)
            {
                cout<<"The point is inside the rectangle."<<endl;
                cout<<endl<<endl;
            }
            else
            {
                cout<<"The point is not inside the rectangle."<<endl;
                cout<<endl<<endl;
            }
            
        }
        else
        {
            cout<<"The point is not inside the rectangle."<<endl;

        }
        
    }while(!(x==0 && y==0 && x1==0 && y1==0));
        
    return 0;
                                     
}
                                     
        
        
