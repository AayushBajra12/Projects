/**********************************************************************************
Aayush Bajracharya
This program splits an input file and creates two files with even and odd characters and finally merges the two files into one single file putting all the odd and even characters together.
**********************************************************************************/


#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>

using namespace std;
void split(char sourceFile[], char destFile1[], char destFile2[]);


void merge(char sourceFile1[], char sourceFile2[], char destFile[]);


int main()
{
	char source[70]; //first input file.
	char outFile1[70];
	char outFile2[70]; //output file after splitting.
	char mergeFile[70]; //output file after merging.
	
    cout << "Enter the name of the input file:";
	cin >> source;
	cout << endl << endl;
    cout<<"Enter the name of the first output file: " <<endl;
	cin>> outFile1;
	cout<< endl;
    cout<<"Enter the name of the second output file : "<<endl;
	cin>>outFile2;
	cout<<endl;
	split(source, outFile1, outFile2);
	cout<<endl<<endl;
    cout<<"Enter the filename to store merged character :  "<<endl;
	cin>>mergeFile;
	cout<<endl;
	merge(outFile1, outFile2, mergeFile);
	return 0;
}
void split(char sourceFile[], char destFile1[], char destFile2[])
{
	ifstream myIn; //input filestream 
	ofstream myOut, myOut2; //output filestream 
	// Attempt to open the file
	myIn.open(sourceFile);
	// Check to make sure it opened
	if( myIn.fail() )
	{
		cout << "Error opening file." << endl;
		exit(EXIT_FAILURE);
	}
	//Attempt to open the first output file
	myOut.open(destFile1);
	// Check to make sure it opened
	if( myOut.fail() )
	{
		cout << "Error opening file." << endl;
		exit(EXIT_FAILURE);
	}
	//Attempt to open the second output file
	myOut2.open(destFile2);
	// Check to make sure it opened
	if( myOut2.fail() )
	{
		cout << "Error opening second output file for splitting." << endl;
		exit(EXIT_FAILURE);
	}
	// Read each character in the file.
	char ch;
	int i = 0;
	myIn.get(ch);  // Priming read
	while( !myIn.eof() )
	{
		//If the character index is even.
		if (i%2==0)
		{
			myOut.put(ch); //Write it to the first output file.
			myIn.get(ch); //Read the next character of input file.
		}
		else //If the character index is odd.
		{
			myOut2.put(ch); //Write it to the second output file.
			myIn.get(ch); //Read the next character of input file.
		}
		i++;
	}
	// Close the file -- necessary if the file is to be reread
	myIn.close();
	myOut.close();
	myOut2.close();
	cout<< "The file has been successfully splitted !!"<<endl;
}

void merge(char sourceFile1[], char sourceFile2[], char destFile[])
{
	ifstream source1, source2; //input filestream variable
	ofstream myOut; //output filestream variable
	// Attempt to open the file
	myOut.open(destFile);
	// Check to make sure it opened
	if( myOut.fail() )
	{
		cout << "Error output file for merging." << endl;
		exit(EXIT_FAILURE);
	}
	//Attempt to open the fist output file
	source1.open(sourceFile1);
	// Check to make sure it opened
	if( source1.fail() )
	{
		cout << "Error opening first input file for merging." << endl;
		exit(EXIT_FAILURE);
	}
	
	source2.open(sourceFile2);  //Attempt to open the second output file
	
	if( source2.fail() )  // Check to make sure it opened
	{
		cout << "Error opening second input file for merging." << endl;
		exit(EXIT_FAILURE);
	}
	// Merging the characters in the file.
	char a, b;
	int i = 0;
	source1.get(a);  // Priming read
	source2.get(b);  // Priming read
	while( !source1.eof() && !source2.eof() )
	{
		//If the character index is even.
		if (i%2==0)
		{
			myOut.put(a); //Write it to the output file.
			source1.get(a); //Read the next character of first input file.
		}
		else //If the character index is odd.
		{
			myOut.put(b); //Write it to the other output file.
			source2.get(b); //Read the next character of the second input file.
		}
		i++;
	}
	// Close the file -- necessary if the file is to be reread
	myOut.close();
	source1.close();
	source2.close();
	cout<< "The file has been successfully merged!!"<<endl; 
}
