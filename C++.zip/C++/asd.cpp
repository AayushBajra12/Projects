/*******************************************************************************
		
		Version 1.0
		
		
		This program gets random point from the user and checks whether or not 
		the point is inside the rectangle. This program continues until the user
		enters (0,0) for both corners of the rectangle.
		
		Title:  assignment 1.cpp
		
*******************************************************************************/
#include <iostream>
#include <cstdlib>

using namespace std;

int main()
{
	int upperleftx;  // The x co-ordinate for the upperleft corner
	int upperlefty;  // The y co-ordinate for the upperleft corner
	int lowerrightx; // The x co-ordinate for the lowerright corner
	int lowerrighty; // The y co-ordinate for the lowerright corner 
	int x;			 // The entered x co-ordinate
	int y;			 // The entered y co-ordinate
	
	do{
		// Prompt the user to enter x and y co-ordinates and the point to be checked
		cout <<"Enter the x co-ordinate of upper left corner : ";
		cin>>upperleftx;
		cout <<"Enter the y co-ordinate of upper left corner : ";
		cin>>upperlefty;
		cout <<"Enter the x co-ordinate of lower right corner : ";
		cin>>lowerrightx;
		cout <<"Enter the y co-ordinate of lower right corner : ";
		cin>>lowerrighty;
		cout<< "Enter the x co-ordinate of the point you want to check : ";
		cin>>x;
		cout<<"Enter the y-co-ordinate of the point you want to check : ";
		cin>>y;
		cout << endl << endl;
		
		// Gives the co-ordinates from the value entered
		cout<<"The co-ordinates for the upper left corner are : (" << upperleftx <<","<<upperlefty <<")"<<endl;
		cout<<"The co-ordinates for the lower right corner are : (" << lowerrightx <<","<<lowerrighty<<")"<<endl;
		cout << endl << endl;
		cout<<"The co-ordinates that we want to check whether or not if it is inside the rectangle are : (" << x <<","<<y<<")"<<endl;
		cout << endl << endl;
		
		// Perform the operation as per the condition
		if(upperleftx==0 && upperlefty==0 && lowerrightx==0 && lowerrighty==0)
		{
			cout<<"Program exitting !!!!!"<<endl;	//Prompt the user to exit the program
			exit(1);	// Exits the program
		}
		else if (x > upperleftx && x < lowerrightx)
		{
			if (y < upperlefty && y > lowerrighty)
			{
				cout <<"The co-ordinates (" << x <<","<<y<<")" << "lies inside the rectangle" << endl;
				cout << endl << endl;
			}	
			else
			{
				cout <<"The co-ordinates (" << x <<","<<y<<")" << "does not lies inside the rectangle. Please try different co-ordinates"  << endl;
				cout << endl << endl;
			}
		}
		else
		{
			cout <<"The co-ordinates (" << x <<","<<y<<")" << "does not lies inside the rectangle. Please try different co-ordinates"  << endl;
			cout << endl << endl;
		}
	// Perform the program again until the user enters (0,0) for both corners of the rectangle	
	}while(upperleftx!=0 && upperlefty!=0 && lowerrightx!=0 && lowerrighty!=0);
	
	return 0;
}
		