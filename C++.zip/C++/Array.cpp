/* Aayush Bajracharya
 Lab Assignment 4
 This program prompts the user for a phrase and creates and array of the strings found in the input.
 */


#include <iostream>
#include <cstring>
#include <iomanip>   
#include <string>

using namespace std;

const int STR_LENGTH = 20;
const int STR_CHAR = 15;

 void parse (char **A, int &s_length);
//Post       : Reads one line of user input from the keyboard and creates an array
//             of strings found in the input.
//Pre        : Function parse array and reference variable s_length

int main(int argc, char** argv) {
    
    cout <<"Enter Phrases to Count The Number of Strings or Enter 'Quit' to exit!!!"<< endl;
    char **a; //Two dimensional Array
    
    a = new char * [STR_LENGTH]; //assign the two dimensional array the global variable 
    for (int i = 0; i < STR_LENGTH; i++) {
        a[i] = new char [STR_CHAR];
        }
    int len = 0; //stores the count of number of words.
    //Infinite Loop
    do{
        
        parse (a,len); //calls the parse function
        cout << "The sentence has " << len << " words" << endl; 
        //loop to print the contents of the array to screen
        for(int  i= 0; i < len; i++){
            
            if(!strcmp(a[0], "Quit")){
                cout << "You have exitted the program." << endl;
                cout << "Thank You. Have A Great Day!!!";
                cout << '\n';
                return 0;//;
                }
            //outputs the string number and it's corresponding word
            cout << "String no." << i <<" is: " << a[i] << endl; 
            }
        len = 0;
        
    }
    while(true); 
    return 0;
}

    
//Post  : The user is prompted.
//Pre   : The program gets input and puts it into array by reading each character
void parse(char **A,int &length){
    int i = 0;
    char ch;
    
    // temp array is used to hold the words
    char temp[50]; 
    cout << "Enter the Phrase:";
    
    
    cin.get(ch);//Gets and reads the input characters inputed by the user
    
  
    while (ch !='\n'){   //while loop to check the white space characters from the input
        while(isspace(ch)){   
            i =0;
            if(ch =='\n'){
                break;
            }
            cin.get(ch);
        }
        
        while(!isspace(ch)){
            if(ch =='\n')
                break;	
            temp[i++] = ch;
            cin.get(ch);
        }
        if (i > 0) {
            temp[i] = '\0';
            
            strcpy(A[length],temp);//Copies the word in the temp array to the A array
            length++;
        }
    }
}
