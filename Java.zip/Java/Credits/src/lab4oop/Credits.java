/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4oop;

/**
 *
 * @author Aayushbajra
 */
class Student{
	protected String name;
	protected int credits;

	public Student(String name, int credits){
		this.name = name;
		this.credits = credits;
	}

	public String getName(){return name;}
	public void setName(String newName){name = newName;}
	public int getCredits(){return credits;}
	public String write(){return "Dragon";}
	public String hobby(){return "Watching Movies";}
}

class CsStudent extends Student{
	private int csCredits;
	public CsStudent(String name, int credits, int csCredits){
		super(name, credits);
		this.csCredits = csCredits;
	}

	public int getCsCredits(){return csCredits;}
	public void addCsCredits(int a){
		csCredits += a;
		credits += a;
	}

	@Override public String write(){return "Code";}
	public String sell(){return "Apps";}
}

class EnglishStudent extends Student{
	private int enCredits;
	public EnglishStudent(String name, int credits, int enCredits){
		super(name, credits);
		this.enCredits = enCredits;
	}

	public int getEnCredits(){return enCredits;}
	public void addEnCredits(int a){
		enCredits += a;
		credits += a;
	}

	@Override public String write(){return "Story";}
	public String write(String language){return "Book in" + language;}
	@Override public String hobby(){return "Reading";}
	public String publish(){return "Poem";}
}

public class Credits{
  public static void main(String[]args){
  	Student Smith = new Student("Smith",25);
  	CsStudent Karla = new CsStudent("Karla",45,28);
  	EnglishStudent Victoria = new EnglishStudent("Victoria",20,11);
  	intern(Smith);
  	intern(Karla);
  	intern(Victoria);
  	Smith = Victoria;
  	Victoria.addEnCredits(15);
  	intern(Smith);
  }

  public static void intern(Student s){
  	System.out.println("\nStudent:" +s.getName()+ ",credits:" +s.getCredits());
  	System.out.println("Student:write" +s.write());
     System.out.println("Student:hobby" +s.hobby());
     if(s instanceof CsStudent){
     	System.out.println("\t CS:sell" + ((CsStudent)s).sell());
     	System.out.println("\t CS:csCredits" + ((CsStudent)s).getCsCredits());
     }
     if(s instanceof EnglishStudent){
     	System.out.println("\t En:write(English)" + ((EnglishStudent)s).write("English"));
     	System.out.println("\t En:enCredits =" + ((EnglishStudent)s).getEnCredits());
     }
   }
 }

