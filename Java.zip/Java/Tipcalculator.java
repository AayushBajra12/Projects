/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tipcalculator2;

/**
 *
 * @author Aayushbajra
 */
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
*
* @author aayushbajra1
*/
public class Tipcalculator2 extends Application {
    double p;
    double total;
    double tamount;
    double per;
@Override
    public void start(Stage primaryStage)throws Exception {
        primaryStage.setTitle("Tip Calculator");
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setHgap(10);
        pane.setVgap(10);
        pane.setPadding(new Insets(25, 25, 25, 25));
        Scene scene = new Scene(pane, 350, 440);

        Text sceneTitle = new Text("Tip Calculator");
        sceneTitle.setFont(Font.font("Arial", FontWeight.NORMAL,20));
        pane.add(sceneTitle, 0, 0, 2, 1);
        Label cAmountL= new Label("Check Amount:");
        pane.add(cAmountL, 0, 1);
        final TextField cAmountF = new TextField();
        cAmountF.setAlignment(Pos.BASELINE_RIGHT);
        pane.add(cAmountF, 1, 1);
        Label tPercentL = new Label("Tip Percent %:");
        pane.add(tPercentL,0,2);
        final TextField tPercentF = new TextField();
        tPercentF.setAlignment(Pos.BASELINE_RIGHT);
        pane.add(tPercentF, 1, 2);


//button
        Button calculateButton = new Button("Calculate");
        HBox hbox = new HBox(10);
        hbox.setAlignment(Pos.BOTTOM_RIGHT);
        hbox.getChildren().add(calculateButton);
        pane.add(hbox, 1, 4);
        //lower fields
        Label tAmountL= new Label("Tip Amount:");
        pane.add(tAmountL, 0, 5);
        final TextField tAmountF = new TextField();
        tAmountF.setAlignment(Pos.BASELINE_RIGHT);
        pane.add(tAmountF, 1, 5);
        Label TotalL = new Label("Total:");
        pane.add(TotalL,0,6);
        final TextField TotalF = new TextField();
        TotalF.setAlignment(Pos.BASELINE_RIGHT);
        pane.add(TotalF, 1, 6);
  
       
  
  
        calculateButton.setOnAction(new EventHandler<ActionEvent>() {

        @Override
        public void handle(ActionEvent t) {
//int amount;
  
        tamount=(((Double.parseDouble(cAmountF.getText()))*(Double.parseDouble(tPercentF.getText())))/100);
        tAmountF.setText("$ "+Double.toString(tamount));
        total=Double.parseDouble(cAmountF.getText())+tamount;
        TotalF.setText("$"+Double.toString(total));
  
  
}
});

primaryStage.setScene(scene);
primaryStage.show();
}

/**
* The main() method is ignored in correctly deployed JavaFX application.
* main() serves only as fallback in case the application can not be
* launched through deployment artifacts, e.g., in IDEs with limited FX
* support. NetBeans ignores main().
*
* @param args the command line arguments
*/
public static void main(String[] args) {
launch(args);
}
}

