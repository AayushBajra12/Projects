/*Aayush Bajracharya
Program 2
Implements the prim's algorithm for finding the minimum spanning tree of a weighted graph.*/
package prims;

/**
 *
 * @author Aayushbajra
 */

import java.util.Scanner;
import java.util.ArrayList;

public class Prims
{
    private final static int INFINITY = Integer.MAX_VALUE;
    private final static int SEEN = -1;
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the number of vertices ");
        int numVertices = in.nextInt();
        int [][] graph = new int[numVertices][numVertices];

        System.out.println("Enter the adjacency matrix one row at a time, use i "
                + "for infinity");
        for(int i=0; i<numVertices; i++)
        {
            for(int j=0; j<numVertices; j++)
            {
                String sVal = in.next();
                int iVal;
                if(sVal.equals("i"))
                    iVal = INFINITY;
                else
                    iVal = Integer.parseInt(sVal);

                graph[i][j] = iVal;
            }
        }

        Prims p = new Prims();
        ArrayList<Edge> list = new ArrayList<Edge>();

        System.out.println("The Adjacency matrix is");
        p.printAdjMatrix(graph);
        list = p.prim(graph);

        System.out.println(list.toString());
        System.out.println("The weight of the spanning tree is " +
                p.getWeight(list));
        in.close();
    }
    /*pre: the 2-d graph has been filled as an adjacency matrix of the graph
    post: returns the list of edges in the minimum spanning tree using the
          prims algorithm where the array nearest stores vertex with the minimum
          weight and the array distance*/
    //stores the weight of the edge
    public ArrayList<Edge> prim(int[][] graph)
    {
        ArrayList<Edge> list = new ArrayList<Edge>();
        int numOfVertices = graph.length;
        int[] nearest = new int[numOfVertices-1];
        int[] distance = new int[numOfVertices-1];
        int vnear = 0;
        int min = INFINITY;

        //init nearest and distance
        for(int i=1; i<numOfVertices; i++)
        {
            nearest[i-1] = 0; //starts at vertex 0
            distance[i-1] = graph[0][i];
        }

        int cont = numOfVertices-1;
        while(cont>0)   //Add all n-1 vertices
        {
            min = INFINITY;
            //find the minimum value from the given list
            for(int i=1; i<numOfVertices; i++)
            {
                if(distance[i-1] < min && distance[i-1]>=0) //check each vertex
                    //for being nearest to the vertex in the nearest array
                {
                    min = distance[i-1];
                    vnear = i-1;
                }
            }

            //add the edge to the arraylist
            int newNearest = 0;
            if(nearest[vnear]==0)//if vnear is 0 add 1 to it, this is cause we start at index 1
            {
                newNearest = 1;
            }
            else
            {
                newNearest = nearest[vnear]+2; //else add two cuz we start at index 2
            }

            Edge edge = new Edge(newNearest,vnear+2, min);//edge connecting vertices indexed by vnear and nearest[vnear
            list.add(edge);
            distance[vnear]= SEEN;

            for(int i=1; i<numOfVertices;i++)
            {
                if(graph[vnear+1][i]<distance[i-1])//if the distance from vnear to nearest is smaller
                {//replace that with the currenct distance and vertex
                    distance[i-1] = graph[vnear+1][i];
                    nearest[i-1] = vnear;
                }
            }
            cont--;
        }
        return list;
    }

    //pre:
    //post: Prints the adjacency matrix of the graph
    private void printAdjMatrix(int[][] graph)
    {
        for(int i=0; i<graph.length;i++)
        {
            for(int j=0; j<graph[0].length;j++)
            {
                if(graph[i][j]<INFINITY)
                    System.out.print(graph[i][j]+" ");
                else
                    System.out.print("inf ");
            }
            System.out.println();
        }
    }

    //pre: the minimum spanning tree is already calculated
    //post: returns the weight of the minimum spanning tree
    private int getWeight(ArrayList<Edge> list)
    {
        int weight = 0;
        for(int i=0;i<list.size();i++)
        {
            weight+=list.get(i).weight;
        }
        return weight;
    }

    //inner class Edge
    private class Edge implements Comparable
    {
        int from;
        int to;
        int weight;

        public Edge(int from, int to, int weight)
        {
            this.from = from;
            this.to = to;
            this.weight = weight;
        }

        //pre:
        //post: compares the edges according to the height
        @Override
        public int compareTo(Object o)
        {
            Edge e = (Edge) o;
            return e.weight-weight;
        }

        //pre:
        //post: return the string representation of the edge
        public String toString()
        {
            return "{{ V" +from+", V"+ to+ "} ," +weight+ " }" +"\n";
        }
    }
}

   